jQuery(document).ready(function(){
	jQuery(".sof-select-item").select2({width: 'resolve', triggerChange: true});
});